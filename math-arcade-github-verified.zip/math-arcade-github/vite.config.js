import { defineConfig } from 'vite';
// Relative asset paths work on GitHub Pages project and user sites.
export default defineConfig({ base: './' });
