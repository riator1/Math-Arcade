# Math Arcade: Positive vs. Negative War

A single-player educational card game playable in any modern browser. Black cards are positive, red cards are negative. Players must enter the sum of their two cards before cards are awarded.

## Play and build locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local address Vite displays. To test and build:

```bash
npm test
npm run build
```

The website is built into the `dist/` directory.

## Publish to a NEW GitHub account

1. Make a new account at https://github.com/signup.
2. Create a **public** repository, for example `math-arcade`. Do not initialize it with a README because one is included here.
3. Extract this ZIP, open a terminal inside its `math-arcade-github` folder, and run:

```bash
git init
git add .
git commit -m "Initial Math Arcade game"
git branch -M main
git remote add origin https://github.com/YOUR_NEW_USERNAME/math-arcade.git
git push -u origin main
```

4. On GitHub open **Settings > Pages**. Under **Build and deployment**, select **GitHub Actions**.
5. The included `.github/workflows/deploy.yml` builds and publishes the site on every push to `main`.
6. The result will typically be `https://YOUR_NEW_USERNAME.github.io/math-arcade/`.

Use the new account's credentials when authenticating your Git push. GitHub may require a credential manager, browser sign-in, or a personal access token rather than a password.

## Rules

- Each player gets their own 30-card deck (15 black positive and 15 red negative cards).
- Each draws two cards per round and adds their values.
- The human player enters the integer sum. Any wrong answer forfeits the pot to the computer.
- With a correct answer, the higher sum wins all cards in the pot.
- Equal sums trigger a WAR announcement. Click **Begin War** to place three cards from each deck face down and draw two additional cards each. Repeat the arithmetic challenge. Repeated ties trigger additional War announcements.
- To encourage occasional ties, the bot may reorder its remaining cards to draw a matching pair. This is not guaranteed. This is **not** a competitive/fair shuffle mode.
- Captured cards are scored rather than recycled. When either deck cannot start another normal round, the remaining cards are assigned based on which deck contains more cards (or split if tied). If a player cannot supply five cards during War, the player with more remaining cards takes the full pot (or the pot is split when counts match).
- The player with the most cards at the end wins.

## Project files

- `src/engine.js`: game rules, draws, scoring, War handling
- `src/app.js`: user interface and optional Web Audio announcement
- `src/style.css`: responsive styling
- `tests/engine.test.js`: rule tests
- `.github/workflows/deploy.yml`: GitHub Pages publishing action

No database, hosting account, online multiplayer, or external API is required. The optional sound is generated in-browser, with no audio file downloads.
