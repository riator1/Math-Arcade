/** Math Arcade pure game engine. No browser dependencies. */
export const sum = cards => cards.reduce((total, card) => total + card.value, 0);
export const signed = number => number > 0 ? `+${number}` : String(number);
export function createDeck(random = Math.random) {
  const deck = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    value: (i % 10 + 1) * (i < 15 ? 1 : -1),
    suit: i < 15 ? (i % 2 ? '♣' : '♠') : (i % 2 ? '♦' : '♥')
  }));
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}
export function newGame(random = Math.random) {
  return { player: createDeck(random), bot: createDeck(random), playerWon: 0, botWon: 0,
    pot: [], playerCards: [], botCards: [], round: 0, wars: 0, ties: 0,
    answered: 0, correct: 0, phase: 'ready', revealed: false,
    title: 'Ready to play?', detail: 'Draw two cards from each deck to begin.',
    nextTieRound: 4 + Math.floor(random() * 3) };
}
function award(state, winner, detail) {
  const next = structuredClone(state), size = next.pot.length;
  if (winner === 'player') next.playerWon += size;
  else if (winner === 'bot') next.botWon += size;
  else { next.playerWon += Math.floor(size / 2); next.botWon += Math.ceil(size / 2); }
  next.pot = [];
  next.phase = 'ready'; next.revealed = true; next.wars = 0;
  next.title = winner === 'player' ? `You win ${size} cards!` : winner === 'bot' ? `Computer wins ${size} cards!` : 'The pot is split.';
  next.detail = detail;
  if (next.player.length < 2 || next.bot.length < 2) {
    const p = next.player.length, b = next.bot.length;
    if (p > b) next.playerWon += p + b;
    else if (b > p) next.botWon += p + b;
    else { next.playerWon += p; next.botWon += b; }
    next.player = []; next.bot = []; next.phase = 'finished';
    next.title = next.playerWon > next.botWon ? 'You win the game!' : next.botWon > next.playerWon ? 'Computer wins the game!' : 'Game tied!';
    next.detail = `Final score: You ${next.playerWon} cards, Computer ${next.botWon} cards.`;
  }
  return next;
}
function matchingPairIndex(cards, target) {
  for (let i = 0; i < cards.length; i++) for (let j = i + 1; j < cards.length; j++) {
    if (cards[i].value + cards[j].value === target) return [i, j];
  }
  return null;
}
function deal(state, war = false) {
  const x = structuredClone(state);
  if (x.player.length < 2 || x.bot.length < 2) throw new Error('Not enough cards for a draw');
  x.playerCards = x.player.splice(0, 2);
  let pair = x.bot.splice(0, 2);
  // Ties are opportunistic, using existing bot cards only, not manufactured cards.
  if (!war && x.round >= x.nextTieRound) {
    const pool = [...pair, ...x.bot];
    const indices = matchingPairIndex(pool, sum(x.playerCards));
    if (indices) {
      pair = [pool[indices[0]], pool[indices[1]]];
      x.bot = pool.filter((_, index) => !indices.includes(index));
      x.nextTieRound = x.round + 5;
    }
  }
  x.botCards = pair;
  x.pot.push(...x.playerCards, ...x.botCards);
  x.phase = 'answer'; x.revealed = false;
  x.title = war ? 'WAR: Calculate the new cards' : 'Calculate your cards';
  x.detail = 'Enter the signed sum of your two cards.';
  return x;
}
export function drawRound(state) {
  if (state.phase !== 'ready') return state;
  const x = structuredClone(state);
  x.round += 1;
  return deal(x);
}
export function submitAnswer(state, answer) {
  if (state.phase !== 'answer' || typeof answer !== 'number' || !Number.isInteger(answer)) return state;
  const x = structuredClone(state), ps = sum(x.playerCards), bs = sum(x.botCards);
  x.answered++; x.revealed = true;
  const comparison = `Your total ${signed(ps)} ${ps > bs ? '>' : ps < bs ? '<' : '='} computer total ${signed(bs)}.`;
  if (answer !== ps) return award(x, 'bot', `Incorrect. The correct sum was ${signed(ps)}. ${comparison}`);
  x.correct++;
  if (ps > bs) return award(x, 'player', `Correct! ${comparison}`);
  if (ps < bs) return award(x, 'bot', `Correct answer, but the computer has the higher sum. ${comparison}`);
  x.wars++; x.ties++; x.phase = 'war-announcement';
  x.title = x.wars === 1 ? 'WAR!' : x.wars === 2 ? 'DOUBLE WAR!' : `WAR ${x.wars}!`;
  x.detail = `Both players scored ${signed(ps)}. The pot contains ${x.pot.length} cards.`;
  return x;
}
export function beginWar(state) {
  if (state.phase !== 'war-announcement') return state;
  const x = structuredClone(state), p = x.player.length, b = x.bot.length;
  if (p < 5 || b < 5) {
    x.pot.push(...x.player.splice(0), ...x.bot.splice(0));
    return award(x, p > b ? 'player' : b > p ? 'bot' : 'tie', 'Not enough cards to complete War. Remaining cards were included in the pot.');
  }
  x.pot.push(...x.player.splice(0, 3), ...x.bot.splice(0, 3));
  return deal(x, true);
}
export function cardConservation(state) {
  return state.player.length + state.bot.length + state.pot.length + state.playerWon + state.botWon;
}
