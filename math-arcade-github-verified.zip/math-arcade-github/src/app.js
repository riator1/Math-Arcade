import './style.css';
import { newGame, drawRound, submitAnswer, beginWar, sum, signed } from './engine.js';
let game = newGame();
let soundEnabled = false;
const $ = id => document.getElementById(id);
function playWarSound() {
  if (!soundEnabled) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    [0, 0.18, 0.36].forEach((offset, i) => {
      const oscillator = ctx.createOscillator(), gain = ctx.createGain();
      oscillator.type = 'triangle'; oscillator.frequency.value = 180 - 25 * i;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + offset);
      gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + offset + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + offset + 0.14);
      oscillator.connect(gain).connect(ctx.destination);
      oscillator.start(ctx.currentTime + offset); oscillator.stop(ctx.currentTime + offset + 0.15);
    });
    setTimeout(() => ctx.close(), 900);
  } catch { /* audio is optional */ }
}
function card(cardData) {
  const node = document.createElement('div');
  node.className = cardData ? `playing-card ${cardData.value < 0 ? 'red' : 'black'}` : 'playing-card back';
  if (cardData) {
    const val = document.createElement('strong'); val.textContent = signed(cardData.value);
    const suit = document.createElement('span'); suit.className = 'suit'; suit.textContent = cardData.suit;
    node.append(val, suit);
    node.setAttribute('aria-label', `${signed(cardData.value)} ${cardData.suit}`);
  } else node.setAttribute('aria-label', 'Face-down card');
  return node;
}
function showCards(id, cards) {
  const host = $(id); host.replaceChildren(...(cards.length ? cards : [null, null]).map(card));
}
function render() {
  $('playerWon').textContent = game.playerWon; $('botWon').textContent = game.botWon;
  $('potCount').textContent = game.pot.length;
  $('playerRemaining').textContent = `${game.player.length} in deck`;
  $('botRemaining').textContent = `${game.bot.length} in deck`;
  showCards('playerCards', game.playerCards); showCards('botCards', game.botCards);
  $('playerTotal').textContent = game.revealed && game.playerCards.length ? signed(sum(game.playerCards)) : '?';
  $('botTotal').textContent = game.revealed && game.botCards.length ? signed(sum(game.botCards)) : '?';
  $('roundStatus').textContent = `ROUND ${game.round || 1}${game.wars ? ` · WAR ${game.wars}` : ''}`;
  $('tieStatus').textContent = `${game.ties} ${game.ties === 1 ? 'tie' : 'ties'}`;
  $('deckCount').textContent = `Decks: ${game.player.length} / ${game.bot.length}`;
  $('accuracy').textContent = `Accuracy: ${game.correct}/${game.answered}`;
  $('roundCount').textContent = `Rounds: ${game.round}`;
  $('feedbackTitle').textContent = game.title; $('feedbackDetail').textContent = game.detail;
  $('warBanner').classList.toggle('hidden', game.phase !== 'war-announcement');
  $('answerPanel').classList.toggle('hidden', game.phase !== 'answer');
  $('drawBtn').disabled = game.phase !== 'ready';
  $('warTitle').textContent = game.title;
  $('warDescription').textContent = game.detail;
  $('warPotCount').textContent = game.pot.length;
  if (game.phase === 'answer') $('answerInput').focus();
}
$('drawBtn').addEventListener('click', () => { game = drawRound(game); $('answerInput').value = ''; render(); });
$('answerForm').addEventListener('submit', event => {
  event.preventDefault();
  if (game.phase !== 'answer') return;
  const raw = $('answerInput').value.trim(), answer = Number(raw);
  if (raw === '' || !Number.isInteger(answer)) return;
  const before = game.phase;
  game = submitAnswer(game, answer);
  $('answerInput').value = '';
  if (before !== 'war-announcement' && game.phase === 'war-announcement') playWarSound();
  render();
});
$('beginWarBtn').addEventListener('click', () => { game = beginWar(game); $('answerInput').value = ''; render(); });
$('resetBtn').addEventListener('click', () => { game = newGame(); $('answerInput').value = ''; render(); });
$('soundBtn').addEventListener('click', () => { soundEnabled = !soundEnabled; $('soundBtn').textContent = `Sound: ${soundEnabled ? 'On' : 'Off'}`; $('soundBtn').setAttribute('aria-pressed', String(soundEnabled)); });
render();
